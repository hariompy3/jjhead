from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User

class StudentRegistrationForm(UserCreationForm):
    date_of_birth = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        help_text="Enter your date of birth"
    )
    class_grade = forms.CharField(
        max_length=10,
        help_text="Enter your class/grade"
    )
    mobile_number = forms.CharField(
        max_length=15,
        help_text="Enter your mobile number"
    )

    class Meta:
        model = User
        fields = ['username',  'date_of_birth', 'class_grade', 'mobile_number',]

    def save(self, commit=True):
        user = super().save(commit=False)
        user.user_type = User.STUDENT
        if commit:
            user.save()
        return user
        
        
        
        
        
        
from django import forms
from .models import Complaint

class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ['topic', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }
        
        
        
from django import forms
from .models import *
class OpinionForm(forms.ModelForm):
    class Meta:
        model = Opinion
        fields = ['title', 'category', 'is_active']

class OptionChoiceForm(forms.ModelForm):
    class Meta:
        model = OptionChoice
        fields = ['text']        

        
                
class ComplaintResolutionForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ['is_resolved' ]                                