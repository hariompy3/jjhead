from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.exceptions import ValidationError

class User(AbstractUser):
    STUDENT = 'S'
    HEAD = 'H'
    USER_TYPES = [
        (STUDENT, 'Student'),
        (HEAD, 'Head Boy/Girl'),
    ]
    
    user_type = models.CharField(max_length=1, choices=USER_TYPES, default=STUDENT)
    date_of_birth = models.DateField(null=True, blank=True)
    class_grade = models.CharField(max_length=10, null=True, blank=True)
    mobile_number = models.CharField(max_length=15, null=True, blank=True)

    def is_student(self):
        return self.user_type == self.STUDENT

    def is_head(self):
        return self.user_type == self.HEAD

class Opinion(models.Model):
    ACADEMIC = 'AC'
    STUDY = 'ST'
    GAMES = 'GM'
    EXTRACURRICULAR = 'EC'
    SCHOOL_POLICIES = 'SP'
    OTHER = 'OT'
    
    CATEGORY_CHOICES = [
        (ACADEMIC, 'Academic'),
        (STUDY, 'Study'),
        (GAMES, 'Games'),
        (EXTRACURRICULAR, 'Extracurricular'),
        (SCHOOL_POLICIES, 'School Policies'),
        (OTHER, 'Other'),
    ]

    title = models.CharField(max_length=200)
    category = models.CharField(max_length=2, choices=CATEGORY_CHOICES, default=OTHER)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_opinions')
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    max_choices = models.PositiveIntegerField(default=4)

    def __str__(self):
        return f"{self.get_category_display()}: {self.title}"

    def clean(self):
        if self.max_choices < 2:
            raise ValidationError("An opinion poll must have at least 2 choices.")

from django.db import models
from django.core.exceptions import ValidationError

class OptionChoice(models.Model):
    opinion = models.ForeignKey('Opinion', on_delete=models.CASCADE, related_name='choices')
    text = models.CharField(max_length=200)

    def __str__(self):
        return f"{self.opinion.title} - {self.text}"

    def clean(self):
        if self.opinion_id is not None:  # Only perform this check if opinion is set
            if self.opinion.choices.count() >= self.opinion.max_choices:
                raise ValidationError(f"This opinion poll already has the maximum number of choices ({self.opinion.max_choices}).")

class UserResponse(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='responses')
    opinion = models.ForeignKey(Opinion, on_delete=models.CASCADE, related_name='responses')
    selected_choice = models.ForeignKey(OptionChoice, on_delete=models.CASCADE, related_name='responses')
    response_date = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'opinion']

    def __str__(self):
        return f"{self.user.username} - {self.opinion.title}"

class Complaint(models.Model):
    PENDING = 'P'
    IN_PROGRESS = 'I'
    RESOLVED = 'R'
    STATUS_CHOICES = [
        (PENDING, 'Pending'),
        (IN_PROGRESS, 'In Progress'),
        (RESOLVED, 'Resolved'),
    ]
    
    TOPIC_CHOICES = [
        ('academic', 'Academic'),
        ('behavior', 'Behavior'),
        ('facility', 'Facility'),
        ('other', 'Other'),
    ]

    submitted_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='complaints')
    topic = models.CharField(max_length=100, choices=TOPIC_CHOICES)
    description = models.TextField()
    is_resolved = models.BooleanField(default=False)
    resolution_date = models.DateTimeField(null=True, blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.topic} - {self.get_status_display()}"