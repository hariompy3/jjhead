from django.contrib.auth.decorators import user_passes_test
from django.shortcuts import redirect
from django.contrib import messages

def student_required(function):
    def wrap(request, *args, **kwargs):
        if request.user.is_authenticated and request.user.is_student():
            return function(request, *args, **kwargs)
        else:
            messages.error(request, "You don't have permission to access this page.")
            return redirect('student_login')  # or wherever you want to redirect unauthorized users
    wrap.__doc__ = function.__doc__
    wrap.__name__ = function.__name__
    return wrap

def head_required(function):
    def wrap(request, *args, **kwargs):
        if request.user.is_authenticated and request.user.is_head():
            return function(request, *args, **kwargs)
        else:
            messages.error(request, "You don't have permission to access this page.")
            return redirect('head_login')  # or wherever you want to redirect unauthorized users
    wrap.__doc__ = function.__doc__
    wrap.__name__ = function.__name__
    return wrap
    
    
    