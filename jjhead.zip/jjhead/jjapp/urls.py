from django.urls import path
from . import views

urlpatterns = [

    path('student/register/', views.student_register, name='student_register'),
    path('student/login/', views.student_login, name='student_login'),
    path('login/', views.head_login, name='head_login'),

    path('student/submit-complaint/', views.submit_complaint, name='submit_complaint'),
    path('head/complaints/', views.complaint_list, name='complaint_list'),
    path('head/complaints/<int:complaint_id>/', views.resolve_complaint, name='resolve_complaint'),

    path('head/create-opinion/', views.create_opinion, name='create_opinion'),
    path('opinions/', views.opinion_list, name='opinion_list'),
    path('student/opinions/<int:opinion_id>/vote/', views.vote_opinion, name='vote_opinion'),
    path('head/opinions/<int:opinion_id>/results/', views.opinion_results, name='opinion_results'),
    
    
    
    
    
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    
    
    path('head/dashboard/', views.head_student_dashboard, name='head_dashboard'),

    path('', views.home, name='home'),

]