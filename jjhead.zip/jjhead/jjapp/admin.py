#from django.contrib import admin
#from .models import *
#@admin.register(Opinion)
#class OpinionAdmin(admin.ModelAdmin):
#    list_display = ('title', 'category', 'created_by', 'created_at', 'is_active')
#    list_filter = ('category', 'is_active', 'created_at')

#@admin.register(Complaint)
#class ComplaintAdmin(admin.ModelAdmin):
#    list_display = ('topic', 'category', 'submitted_by', 'status', 'submitted_at')
#    list_filter = ('category', 'status', 'submitted_at')



from django.contrib import admin
from .models import *

admin.site.register(User)