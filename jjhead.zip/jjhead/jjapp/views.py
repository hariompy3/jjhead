from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from .forms import StudentRegistrationForm
from .models import User

def student_register(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.user_type = User.STUDENT
            user.save()
            login(request, user)
            messages.success(request, f"Welcome, {user.username}! Your account has been created successfully.")
            return redirect('student_dashboard')  # Redirect to student dashboard after successful registration
    else:
        form = StudentRegistrationForm()
    return render(request, 'student_register.html', {'form': form})

def student_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.is_student():
                login(request, user)
                messages.info(request, f"You are now logged in as {username}")
                return redirect('student_dashboard')  # Redirect to student dashboard after successful login
            else:
                messages.error(request, "Invalid username or password, or you don't have student privileges.")
        else:
            messages.error(request, "Invalid username or password")
    form = AuthenticationForm()
    return render(request, 'student_login.html', {'form': form})

def head_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.is_head():
                login(request, user)
                messages.info(request, f"Welcome, {username}! You are now logged in as a head boy/girl.")
                return redirect('head_dashboard')  # Redirect to head boy/girl dashboard after successful login
            else:
                messages.error(request, "Invalid username or password, or you don't have head boy/girl privileges.")
        else:
            messages.error(request, "Invalid username or password")
    form = AuthenticationForm()
    return render(request, 'head_login.html', {'form': form})
    
    
    
    
    
    
    
    
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Complaint
from .forms import *
from django.utils import timezone
from .decorators import student_required, head_required

@login_required
@student_required
def submit_complaint(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.submitted_by = request.user
            complaint.save()
            messages.success(request, "Your complaint has been submitted successfully.")
            return redirect('student_dashboard')
    else:
        form = ComplaintForm()
    return render(request, 'submit_complaint.html', {'form': form})

@login_required
@head_required
def complaint_list(request):
    complaints = Complaint.objects.all()
    return render(request, 'complaint_list.html', {'complaints': complaints})


@login_required
@head_required
def resolve_complaint(request, complaint_id):
    complaint = Complaint.objects.get(id=complaint_id)
    if request.method == 'POST':
        form = ComplaintResolutionForm(request.POST, instance=complaint)
        if form.is_valid():
            if form.cleaned_data['is_resolved']:
                complaint.resolution_date = timezone.now()
            form.save()
            return redirect('complaint_list')
    else:
        form = ComplaintResolutionForm(instance=complaint)
    return render(request, 'resolve_complaint.html', {'form': form, 'complaint': complaint})    
    
    
    
    
    
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.forms import formset_factory
from .models import Opinion, OptionChoice, UserResponse
from .forms import OpinionForm, OptionChoiceForm
from .decorators import student_required, head_required


from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.forms import formset_factory
from .models import Opinion, OptionChoice
from .forms import OpinionForm, OptionChoiceForm
from .decorators import head_required


@login_required
@head_required
def create_opinion(request):
    OptionChoiceFormSet = formset_factory(OptionChoiceForm, extra=1, min_num=2, validate_min=True)
    if request.method == 'POST':
        form = OpinionForm(request.POST)
        formset = OptionChoiceFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            opinion = form.save(commit=False)
            opinion.created_by = request.user
            opinion.save()
            for choice_form in formset:
                if choice_form.cleaned_data.get('text'):
                    OptionChoice.objects.create(opinion=opinion, text=choice_form.cleaned_data['text'])
            messages.success(request, "Opinion poll created successfully.")
            return redirect('opinion_list')
    else:
        form = OpinionForm()
        formset = OptionChoiceFormSet()
    return render(request, 'create_opinion.html', {'form': form, 'formset': formset})


@login_required
def opinion_list(request):
    if request.user.is_head():
        opinions = Opinion.objects.all().order_by('-created_at')
    else:
        responded_opinions = UserResponse.objects.filter(user=request.user).values_list('opinion', flat=True)
        opinions = Opinion.objects.filter(is_active=True).exclude(id__in=responded_opinions).order_by('-created_at')
    return render(request, 'opinion_list.html', {'opinions': opinions})

@login_required
@student_required
def vote_opinion(request, opinion_id):
    opinion = get_object_or_404(Opinion, id=opinion_id, is_active=True)
    if UserResponse.objects.filter(user=request.user, opinion=opinion).exists():
        messages.error(request, "You have already voted on this opinion.")
        return redirect('opinion_list')
    
    if request.method == 'POST':
        choice_id = request.POST.get('choice')
        if choice_id:
            choice = get_object_or_404(OptionChoice, id=choice_id, opinion=opinion)
            UserResponse.objects.create(user=request.user, opinion=opinion, selected_choice=choice)
            messages.success(request, "Your vote has been recorded.")
            return redirect('student_dashboard')
        else:
            messages.error(request, "Please select an option.")
    
    return render(request, 'vote_opinion.html', {'opinion': opinion})

@login_required
@head_required
def opinion_results(request, opinion_id):
    opinion = get_object_or_404(Opinion, id=opinion_id)
    choices = opinion.choices.all()
    results = []
    total_votes = UserResponse.objects.filter(opinion=opinion).count()
    for choice in choices:
        vote_count = choice.responses.count()
        percentage = (vote_count / total_votes * 100) if total_votes > 0 else 0
        results.append({
            'text': choice.text,
            'votes': vote_count,
            'percentage': round(percentage, 2)
        })
    return render(request, 'opinion_results.html', {'opinion': opinion, 'results': results, 'total_votes': total_votes})    
    
    
    
    
    
    
    
    
    
    
    
    
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Complaint

@login_required
@student_required
def student_dashboard(request):
    student = request.user
    total_complaints = Complaint.objects.filter(submitted_by=student).count()
    solved_complaints = Complaint.objects.filter(submitted_by=student, is_resolved = True).count()
    
    pending_complaints = Complaint.objects.filter(submitted_by=student, is_resolved=False).count()
    
    
    
    solve_ratio = (solved_complaints / total_complaints * 100) if total_complaints > 0 else 0
    
    recent_complaints = Complaint.objects.filter(submitted_by=student).order_by('-submitted_at')[:5]

    context = {
        'student': student,
        'total_complaints': total_complaints,
        'solved_complaints': solved_complaints,
        'pending_complaints': pending_complaints,

        'solve_ratio': round(solve_ratio, 2),
        'recent_complaints': recent_complaints,
    }
    
    return render(request, 'student_dashboard.html', context)    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Complaint, Opinion

@login_required
@head_required
def head_student_dashboard(request):
    head_student = request.user.username
    total_students = User.objects.filter(user_type="S").count()
    total_complaints = Complaint.objects.count()
    pending_complaints = Complaint.objects.filter(is_resolved=False).count()
    resolved_complaints = Complaint.objects.filter(is_resolved=True).count()

    recent_opinions = Opinion.objects.order_by('-created_at')[:5]
    recent_complaints = Complaint.objects.order_by('-submitted_at')[:5]

    context = {
        'head_student': head_student,
        'total_students': total_students,
        'total_complaints': total_complaints,
        'pending_complaints': pending_complaints,
        'resolved_complaints': resolved_complaints,
        'recent_opinions': recent_opinions,
        'recent_complaints': recent_complaints,
    }
    
    return render(request, 'head_student_dashboard.html', context)  
  
    
      
        
          
              
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .decorators import student_required, head_required

def home(request):
    if request.user.is_authenticated:
        if request.user.is_student():
            return redirect('student_dashboard')
        elif request.user.is_head():
            return redirect('head_dashboard')
        else:
            # If the user is neither a student nor a head, redirect to student login
            return redirect('student_login')
    else:
        # If the user is not authenticated, redirect to student login
        return redirect('student_login')                                                   